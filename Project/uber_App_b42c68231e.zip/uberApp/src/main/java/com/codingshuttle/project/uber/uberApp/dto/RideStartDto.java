package com.codingshuttle.project.uber.uberApp.dto;

import lombok.Data;

@Data
public class RideStartDto {
    String otp;
}

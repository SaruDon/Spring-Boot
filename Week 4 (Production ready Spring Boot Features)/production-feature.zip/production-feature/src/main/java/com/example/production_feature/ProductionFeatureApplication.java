package com.example.production_feature;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductionFeatureApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductionFeatureApplication.class, args);
	}

}

package com.codingshuttle.project.uber.uberApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UberAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

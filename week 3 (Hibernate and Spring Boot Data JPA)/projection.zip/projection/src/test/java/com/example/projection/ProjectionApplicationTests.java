package com.example.projection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}

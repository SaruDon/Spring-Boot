package com.fcrit.week2HomeWorkexample.Department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}

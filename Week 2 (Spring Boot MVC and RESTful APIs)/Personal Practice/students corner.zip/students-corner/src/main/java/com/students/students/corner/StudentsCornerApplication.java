package com.students.students.corner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsCornerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsCornerApplication.class, args);
	}

}
